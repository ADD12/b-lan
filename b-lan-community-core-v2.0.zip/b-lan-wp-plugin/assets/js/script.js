/**
 * Frontend script for B-LAN Plugin V.3
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        var nodeUrl = blanSettings.nodeUrl || 'http://localhost:3000';
        var communityId = blanSettings.communityId || 'CIM-99';

        // 1. Load B-LAN Profile Card
        if ($('#blan-profile-root').length) {
            fetchProfileData(nodeUrl);
        }

        // 2. Load B-LAN Community Directory Card
        if ($('#blan-directory-root').length) {
            fetchDirectoryData(nodeUrl);
        }
    });

    /**
     * Fetches current PIM Profile from local B-LAN database
     */
    function fetchProfileData(nodeUrl) {
        var root = $('#blan-profile-root');

        // Check localStorage as local-first fallback simulation
        var cachedUser = null;
        try {
            cachedUser = JSON.parse(localStorage.getItem('current_auth_user'));
        } catch(e) {}

        // Fallback profile if node is offline and no cache exists
        var fallbackProfile = {
            name: "John Neighbor",
            address: "Sector B-4, Unit 12",
            karmaBalance: 520,
            solarWatts: 1450,
            skills: ["General Labor", "SDR Radio Setup", "Solar Maintenance"],
            avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=JohnNeighbor"
        };

        var user = cachedUser || fallbackProfile;

        // Simulate local-first dynamic mesh sync
        setTimeout(function() {
            var html = `
                <div class="blan-card">
                    <div class="blan-profile-header">
                        <img src="${user.avatar}" class="blan-avatar" alt="Avatar">
                        <div>
                            <h4 class="blan-name">${user.name}</h4>
                            <p class="blan-address"><i class="fa-solid fa-location-dot"></i> ${user.address}</p>
                        </div>
                    </div>
                    
                    <div class="blan-stats-grid">
                        <div class="blan-stat-box">
                            <div class="blan-stat-label">Karma Trust Balance</div>
                            <div class="blan-stat-value karma">${user.karmaBalance} K</div>
                        </div>
                        <div class="blan-stat-box">
                            <div class="blan-stat-label">Solar Watts Reserve</div>
                            <div class="blan-stat-value solar">${user.solarWatts.toLocaleString()} Wh</div>
                        </div>
                    </div>

                    <div class="blan-skills-section">
                        <div class="blan-skills-title">Active PIM Skills</div>
                        <div class="blan-skills-list">
                            ${user.skills.map(skill => `<span class="blan-skill-tag">${skill}</span>`).join('')}
                        </div>
                    </div>
                </div>
            `;
            root.html(html);
        }, 800);
    }

    /**
     * Fetches community directory mesh shards
     */
    function fetchDirectoryData(nodeUrl) {
        var root = $('#blan-directory-root');

        var fallbackMembers = [
            { id: 1, name: "Alice Shard", address: "Sector A-1, Unit 09", karmaBalance: 1200, solarWatts: 4500, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Alice" },
            { id: 2, name: "Bob Node", address: "Sector B-2, Unit 04", karmaBalance: 320, solarWatts: 120, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Bob" },
            { id: 3, name: "Charlie Mesh", address: "Sector B-4, Unit 01", karmaBalance: 850, solarWatts: 2400, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Charlie" },
            { id: 4, name: "Diana Fox", address: "Sector C-1, Unit 15", karmaBalance: 610, solarWatts: 950, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Diana" },
            { id: 5, name: "Ethan Solar", address: "Sector C-3, Unit 22", karmaBalance: 980, solarWatts: 3800, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Ethan" }
        ];

        // Retrieve user registry if available in storage
        var registry = [];
        try {
            registry = JSON.parse(localStorage.getItem('user_registry')) || [];
        } catch(e) {}

        var members = registry.length > 0 ? registry : fallbackMembers;

        setTimeout(function() {
            var html = `<div class="blan-directory-grid">`;
            
            members.forEach(function(m) {
                html += `
                    <div class="blan-member-card">
                        <div class="blan-member-info">
                            <img src="${m.avatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=' + m.name}" class="blan-member-avatar" alt="Member Avatar">
                            <div>
                                <h5 class="blan-member-name">${m.name}</h5>
                                <p class="blan-member-address">${m.address || 'Sector B-4, Mesh Unit'}</p>
                            </div>
                        </div>
                        <div class="blan-member-stats">
                            <span style="color: #a5b4fc;"><i class="fa-solid fa-coins"></i> ${m.karmaBalance || 500} K</span>
                            <span style="color: #fbbf24;"><i class="fa-solid fa-bolt"></i> ${(m.solarWatts || 1000).toLocaleString()} Wh</span>
                        </div>
                    </div>
                `;
            });

            html += `</div>`;
            root.html(html);
        }, 1000);
    }

})(jQuery);
