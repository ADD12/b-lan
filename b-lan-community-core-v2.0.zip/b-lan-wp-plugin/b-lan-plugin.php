<?php
/**
 * Plugin Name: B-LAN Mesh Connector
 * Plugin URI: https://github.com/ADD12/b-lan
 * Description: Connect your WordPress site to the B-LAN Local-First Sharded Mesh Network. Enable rapid local profile synchronization, local identity widgets, and Karma Ledger queries.
 * Version: 3.0.0
 * Author: B-LAN Core Development
 * Author URI: https://github.com/ADD12/b-lan
 * License: GPLv2 or later
 * Text Domain: b-lan-plugin
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define Constants.
define( 'BLAN_PLUGIN_VERSION', '3.0.0' );
define( 'BLAN_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BLAN_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Activation Hook: Automatically create B-LAN Member Pages.
 */
register_activation_hook( __FILE__, 'blan_plugin_activate' );
function blan_plugin_activate() {
    // Save default settings if not exists
    if ( ! get_option( 'blan_node_url' ) ) {
        update_option( 'blan_node_url', 'http://localhost:3000' );
    }
    if ( ! get_option( 'blan_community_id' ) ) {
        update_option( 'blan_community_id', 'CIM-99' );
    }

    // Auto-create "B-LAN Profile Dashboard" Page
    $profile_page = array(
        'post_title'    => 'B-LAN Profile Dashboard',
        'post_content'  => '[blan_member_profile]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_name'     => 'blan-profile'
    );
    if ( ! get_page_by_path( 'blan-profile' ) ) {
        wp_insert_post( $profile_page );
    }

    // Auto-create "B-LAN Community Directory" Page
    $directory_page = array(
        'post_title'    => 'B-LAN Community Directory',
        'post_content'  => '[blan_community_directory]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_name'     => 'blan-directory'
    );
    if ( ! get_page_by_path( 'blan-directory' ) ) {
        wp_insert_post( $directory_page );
    }
}

/**
 * Enqueue Frontend Styles and Scripts
 */
add_action( 'wp_enqueue_scripts', 'blan_plugin_enqueue_scripts' );
function blan_plugin_enqueue_scripts() {
    wp_enqueue_style( 'blan-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0' );
    wp_enqueue_style( 'blan-plugin-style', BLAN_PLUGIN_URL . 'assets/css/style.css', array(), BLAN_PLUGIN_VERSION );
    wp_enqueue_script( 'blan-plugin-script', BLAN_PLUGIN_URL . 'assets/js/script.js', array( 'jquery' ), BLAN_PLUGIN_VERSION, true );

    // Localize settings for frontend script
    wp_localize_script( 'blan-plugin-script', 'blanSettings', array(
        'nodeUrl'     => esc_url( get_option( 'blan_node_url', 'http://localhost:3000' ) ),
        'communityId' => esc_attr( get_option( 'blan_community_id', 'CIM-99' ) )
    ) );
}

/**
 * Load Admin Settings
 */
if ( is_admin() ) {
    require_once BLAN_PLUGIN_DIR . 'includes/admin-settings.php';
}

/**
 * Shortcode: [blan_member_profile]
 * Renders a highly polished citizen passport view synchronized with B-LAN
 */
add_shortcode( 'blan_member_profile', 'blan_render_member_profile' );
function blan_render_member_profile( $atts ) {
    ob_start();
    ?>
    <div id="blan-profile-root" class="blan-widget-container">
        <!-- Render state dynamically via JS/Fetch or server-side fallback -->
        <div class="blan-card blan-loading">
            <div class="blan-spinner"></div>
            <p>Syncing with local B-LAN Node...</p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Shortcode: [blan_community_directory]
 * Renders list of neighboring peers in the current Community Mesh
 */
add_shortcode( 'blan_community_directory', 'blan_render_community_directory' );
function blan_render_community_directory( $atts ) {
    ob_start();
    ?>
    <div id="blan-directory-root" class="blan-widget-container">
        <div class="blan-card blan-loading">
            <div class="blan-spinner"></div>
            <p>Scanning community mesh shards...</p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
