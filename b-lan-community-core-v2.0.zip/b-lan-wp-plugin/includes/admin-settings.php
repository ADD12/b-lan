<?php
/**
 * Admin settings panel for B-LAN Plugin V.3
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_menu', 'blan_plugin_add_admin_menu' );
function blan_plugin_add_admin_menu() {
    add_menu_page(
        'B-LAN Settings',
        'B-LAN Mesh',
        'manage_options',
        'b-lan-settings',
        'blan_plugin_render_settings_page',
        'dashicons-networking',
        80
    );
}

add_action( 'admin_init', 'blan_plugin_settings_init' );
function blan_plugin_settings_init() {
    register_setting( 'blan_settings_group', 'blan_node_url' );
    register_setting( 'blan_settings_group', 'blan_community_id' );
    register_setting( 'blan_settings_group', 'blan_shard_license' );
}

function blan_plugin_render_settings_page() {
    // Check if user has permission
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // Process manual page creation request
    if ( isset( $_POST['blan_recreate_pages'] ) && check_admin_referer( 'blan_recreate_nonce' ) ) {
        blan_plugin_activate();
        echo '<div class="notice notice-success is-dismissible"><p><strong>Success:</strong> B-LAN Member and Directory pages have been created!</p></div>';
    }

    $node_url = get_option( 'blan_node_url', 'http://localhost:3000' );
    $community_id = get_option( 'blan_community_id', 'CIM-99' );
    $license_key = get_option( 'blan_shard_license', 'FREE-COMMUNITY-SHARD' );
    ?>
    <div class="wrap blan-admin-wrap" style="max-width: 850px; font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen-Sans,Ubuntu,Cantarell,sans-serif;">
        <div style="background: #0f172a; border-radius: 16px; padding: 30px; border: 1px solid #334155; margin-top: 20px; color: #f1f5f9; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3);">
            
            <!-- Header banner -->
            <div style="display: flex; align-items: center; justify-content: space-between; border-b: 1px solid #1e293b; padding-bottom: 20px; margin-bottom: 30px;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="background: #4f46e5; color: white; width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 900; box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);">
                        B
                    </div>
                    <div>
                        <h1 style="color: white; margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">B-LAN <span style="color: #6366f1;">Plugin V.3</span></h1>
                        <p style="margin: 3px 0 0; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase; letter-spacing: 1px;">Local-First Mesh Integration</p>
                    </div>
                </div>
                <div style="background: rgba(16, 185, 129, 0.1); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 20px; padding: 6px 14px; font-size: 11px; font-weight: bold; letter-spacing: 0.5px; text-transform: uppercase;">
                    Mesh Link Ready
                </div>
            </div>

            <!-- Settings Form -->
            <form method="post" action="options.php">
                <?php settings_fields( 'blan_settings_group' ); ?>
                <?php do_settings_sections( 'blan_settings_group' ); ?>

                <div style="background: #1e293b; border-radius: 12px; padding: 25px; margin-bottom: 25px; border: 1px solid #334155;">
                    <h3 style="color: white; margin-top: 0; font-size: 16px; font-weight: 700; border-bottom: 1px solid #334155; padding-bottom: 10px;">Rapid Setup Wizard</h3>
                    
                    <table class="form-table" style="color: #94a3b8; width: 100%;">
                        <tr valign="top">
                            <th scope="row" style="color: #cbd5e1; font-weight: 600; width: 250px;">B-LAN Node Address</th>
                            <td>
                                <input type="url" name="blan_node_url" value="<?php echo esc_url( $node_url ); ?>" style="width: 100%; max-width: 400px; background: #0f172a; border: 1px solid #334155; color: #f1f5f9; padding: 8px 12px; border-radius: 6px;" placeholder="e.g. http://192.168.1.100:3000" required />
                                <p class="description" style="color: #64748b; margin-top: 5px; font-size: 11px;">The local IP/host URL of your active B-LAN physical node.</p>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" style="color: #cbd5e1; font-weight: 600;">Community Module ID (CIM)</th>
                            <td>
                                <input type="text" name="blan_community_id" value="<?php echo esc_attr( $community_id ); ?>" style="width: 100%; max-width: 400px; background: #0f172a; border: 1px solid #334155; color: #f1f5f9; padding: 8px 12px; border-radius: 6px;" placeholder="e.g. CIM-99" required />
                                <p class="description" style="color: #64748b; margin-top: 5px; font-size: 11px;">Identifies which physical neighborhood mesh ledger is targeted.</p>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" style="color: #cbd5e1; font-weight: 600;">License Node Shard</th>
                            <td>
                                <input type="text" name="blan_shard_license" value="<?php echo esc_attr( $license_key ); ?>" style="width: 100%; max-width: 400px; background: #0f172a; border: 1px solid #334155; color: #f1f5f9; padding: 8px 12px; border-radius: 6px;" placeholder="e.g. FREE-COMMUNITY-SHARD" />
                                <p class="description" style="color: #64748b; margin-top: 5px; font-size: 11px;">Local developer cluster license key.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div style="display: flex; gap: 15px; align-items: center;">
                    <?php submit_button( 'Save Mesh Settings', 'primary', 'submit', false, array( 'style' => 'background: #4f46e5; border: none; color: white; padding: 10px 20px; font-weight: bold; border-radius: 8px; cursor: pointer; box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);' ) ); ?>
                </div>
            </form>

            <!-- Re-create Pages Tool Section -->
            <div style="background: rgba(79, 70, 229, 0.05); border-radius: 12px; padding: 25px; margin-top: 30px; border: 1px solid rgba(79, 70, 229, 0.15);">
                <h3 style="color: #a5b4fc; margin-top: 0; font-size: 15px; font-weight: 700;">Local Page Generator</h3>
                <p style="color: #94a3b8; font-size: 13px; margin-bottom: 20px;">
                    Click below to dynamically generate standard B-LAN pages such as **B-LAN Profile Dashboard** (`[blan_member_profile]`) and **B-LAN Community Directory** (`[blan_community_directory]`).
                </p>
                
                <form method="post" action="">
                    <?php wp_nonce_field( 'blan_recreate_nonce', 'blan_recreate_nonce' ); ?>
                    <input type="submit" name="blan_recreate_pages" class="button" value="Rapid Page Installation" style="background: transparent; border: 1px solid #4f46e5; color: #a5b4fc; padding: 8px 16px; font-weight: bold; border-radius: 8px; cursor: pointer; hover:bg-indigo-600;" />
                </form>
            </div>

            <!-- Footer info -->
            <div style="margin-top: 30px; border-top: 1px solid #1e293b; padding-top: 15px; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #475569;">
                <span>B-LAN Core Stack v2.0 // WP Module V.3</span>
                <span>Designed for 100% Offline Resilience</span>
            </div>

        </div>
    </div>
    <?php
}
