# B-LAN Optional Modules
## Modular Shard Ecosystem

This directory contains optional modules (shards) that can be added to a base B-LAN installation. Each module is designed to be self-contained and mesh-compatible.

### Available Modules:
- **Security Cam B-LAN (`/security`)**: Advanced mesh-linked security camera with zone detection and sentry mode.

### Installation:
To install a module, add its Shard ID to your `installedShards` list in your PIM Profile.

---
*B-LAN: Reclaiming the network, one module at a time.*
