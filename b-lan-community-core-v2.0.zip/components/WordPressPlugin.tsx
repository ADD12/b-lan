import React, { useState } from 'react';
import JSZip from 'jszip';
import { Download, CheckCircle, HelpCircle, Server, Code, Settings } from 'lucide-react';

const WordPressPlugin: React.FC = () => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // File templates stored as static strings to guarantee zero runtime fetch errors in iframe
  const bLanPluginPhp = `<?php
/**
 * Plugin Name: B-LAN Mesh Connector
 * Plugin URI: https://github.com/ADD12/b-lan
 * Description: Connect your WordPress site to the B-LAN Local-First Sharded Mesh Network. Enable rapid local profile synchronization, local identity widgets, and Karma Ledger queries.
 * Version: 3.0.0
 * Author: B-LAN Core Development
 * Author URI: https://github.com/ADD12/b-lan
 * License: GPLv2 or later
 * Text Domain: b-lan-plugin
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define Constants.
define( 'BLAN_PLUGIN_VERSION', '3.0.0' );
define( 'BLAN_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BLAN_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Activation Hook: Automatically create B-LAN Member Pages.
 */
register_activation_hook( __FILE__, 'blan_plugin_activate' );
function blan_plugin_activate() {
    // Save default settings if not exists
    if ( ! get_option( 'blan_node_url' ) ) {
        update_option( 'blan_node_url', 'http://localhost:3000' );
    }
    if ( ! get_option( 'blan_community_id' ) ) {
        update_option( 'blan_community_id', 'CIM-99' );
    }

    // Auto-create "B-LAN Profile Dashboard" Page
    $profile_page = array(
        'post_title'    => 'B-LAN Profile Dashboard',
        'post_content'  => '[blan_member_profile]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_name'     => 'blan-profile'
    );
    if ( ! get_page_by_path( 'blan-profile' ) ) {
        wp_insert_post( $profile_page );
    }

    // Auto-create "B-LAN Community Directory" Page
    $directory_page = array(
        'post_title'    => 'B-LAN Community Directory',
        'post_content'  => '[blan_community_directory]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_name'     => 'blan-directory'
    );
    if ( ! get_page_by_path( 'blan-directory' ) ) {
        wp_insert_post( $directory_page );
    }
}

/**
 * Enqueue Frontend Styles and Scripts
 */
add_action( 'wp_enqueue_scripts', 'blan_plugin_enqueue_scripts' );
function blan_plugin_enqueue_scripts() {
    wp_enqueue_style( 'blan-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0' );
    wp_enqueue_style( 'blan-plugin-style', BLAN_PLUGIN_URL . 'assets/css/style.css', array(), BLAN_PLUGIN_VERSION );
    wp_enqueue_script( 'blan-plugin-script', BLAN_PLUGIN_URL . 'assets/js/script.js', array( 'jquery' ), BLAN_PLUGIN_VERSION, true );

    // Localize settings for frontend script
    wp_localize_script( 'blan-plugin-script', 'blanSettings', array(
        'nodeUrl'     => esc_url( get_option( 'blan_node_url', 'http://localhost:3000' ) ),
        'communityId' => esc_attr( get_option( 'blan_community_id', 'CIM-99' ) )
    ) );
}

/**
 * Load Admin Settings
 */
if ( is_admin() ) {
    require_once BLAN_PLUGIN_DIR . 'includes/admin-settings.php';
}

/**
 * Shortcode: [blan_member_profile]
 */
add_shortcode( 'blan_member_profile', 'blan_render_member_profile' );
function blan_render_member_profile( $atts ) {
    ob_start();
    ?>
    <div id="blan-profile-root" class="blan-widget-container">
        <div class="blan-card blan-loading">
            <div class="blan-spinner"></div>
            <p>Syncing with local B-LAN Node...</p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Shortcode: [blan_community_directory]
 */
add_shortcode( 'blan_community_directory', 'blan_render_community_directory' );
function blan_render_community_directory( $atts ) {
    ob_start();
    ?>
    <div id="blan-directory-root" class="blan-widget-container">
        <div class="blan-card blan-loading">
            <div class="blan-spinner"></div>
            <p>Scanning community mesh shards...</p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
`;

  const adminSettingsPhp = `<?php
/**
 * Admin settings panel for B-LAN Plugin V.3
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_menu', 'blan_plugin_add_admin_menu' );
function blan_plugin_add_admin_menu() {
    add_menu_page(
        'B-LAN Settings',
        'B-LAN Mesh',
        'manage_options',
        'b-lan-settings',
        'blan_plugin_render_settings_page',
        'dashicons-networking',
        80
    );
}

add_action( 'admin_init', 'blan_plugin_settings_init' );
function blan_plugin_settings_init() {
    register_setting( 'blan_settings_group', 'blan_node_url' );
    register_setting( 'blan_settings_group', 'blan_community_id' );
    register_setting( 'blan_settings_group', 'blan_shard_license' );
}

function blan_plugin_render_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( isset( $_POST['blan_recreate_pages'] ) && check_admin_referer( 'blan_recreate_nonce' ) ) {
        blan_plugin_activate();
        echo '<div class="notice notice-success is-dismissible"><p><strong>Success:</strong> B-LAN Member and Directory pages have been created!</p></div>';
    }

    $node_url = get_option( 'blan_node_url', 'http://localhost:3000' );
    $community_id = get_option( 'blan_community_id', 'CIM-99' );
    $license_key = get_option( 'blan_shard_license', 'FREE-COMMUNITY-SHARD' );
    ?>
    <div class="wrap blan-admin-wrap" style="max-width: 850px; font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen-Sans,Ubuntu,Cantarell,sans-serif;">
        <div style="background: #0f172a; border-radius: 16px; padding: 30px; border: 1px solid #334155; margin-top: 20px; color: #f1f5f9; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3);">
            <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #1e293b; padding-bottom: 20px; margin-bottom: 30px;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="background: #4f46e5; color: white; width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 900; box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);">
                        B
                    </div>
                    <div>
                        <h1 style="color: white; margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">B-LAN <span style="color: #6366f1;">Plugin V.3</span></h1>
                        <p style="margin: 3px 0 0; font-size: 11px; color: #64748b; font-family: monospace; text-transform: uppercase; letter-spacing: 1px;">Local-First Mesh Integration</p>
                    </div>
                </div>
                <div style="background: rgba(16, 185, 129, 0.1); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 20px; padding: 6px 14px; font-size: 11px; font-weight: bold; letter-spacing: 0.5px; text-transform: uppercase;">
                    Mesh Link Ready
                </div>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields( 'blan_settings_group' ); ?>
                <?php do_settings_sections( 'blan_settings_group' ); ?>

                <div style="background: #1e293b; border-radius: 12px; padding: 25px; margin-bottom: 25px; border: 1px solid #334155;">
                    <h3 style="color: white; margin-top: 0; font-size: 16px; font-weight: 700; border-bottom: 1px solid #334155; padding-bottom: 10px;">Rapid Setup Wizard</h3>
                    <table class="form-table" style="color: #94a3b8; width: 100%;">
                        <tr valign="top">
                            <th scope="row" style="color: #cbd5e1; font-weight: 600; width: 250px;">B-LAN Node Address</th>
                            <td>
                                <input type="url" name="blan_node_url" value="<?php echo esc_url( $node_url ); ?>" style="width: 100%; max-width: 400px; background: #0f172a; border: 1px solid #334155; color: #f1f5f9; padding: 8px 12px; border-radius: 6px;" placeholder="e.g. http://192.168.1.100:3000" required />
                                <p class="description" style="color: #64748b; margin-top: 5px; font-size: 11px;">The local IP/host URL of your active B-LAN physical node.</p>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" style="color: #cbd5e1; font-weight: 600;">Community Module ID (CIM)</th>
                            <td>
                                <input type="text" name="blan_community_id" value="<?php echo esc_attr( $community_id ); ?>" style="width: 100%; max-width: 400px; background: #0f172a; border: 1px solid #334155; color: #f1f5f9; padding: 8px 12px; border-radius: 6px;" placeholder="e.g. CIM-99" required />
                                <p class="description" style="color: #64748b; margin-top: 5px; font-size: 11px;">Identifies which physical neighborhood mesh ledger is targeted.</p>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" style="color: #cbd5e1; font-weight: 600;">License Node Shard</th>
                            <td>
                                <input type="text" name="blan_shard_license" value="<?php echo esc_attr( $license_key ); ?>" style="width: 100%; max-width: 400px; background: #0f172a; border: 1px solid #334155; color: #f1f5f9; padding: 8px 12px; border-radius: 6px;" placeholder="e.g. FREE-COMMUNITY-SHARD" />
                                <p class="description" style="color: #64748b; margin-top: 5px; font-size: 11px;">Local developer cluster license key.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div style="display: flex; gap: 15px; align-items: center;">
                    <?php submit_button( 'Save Mesh Settings', 'primary', 'submit', false, array( 'style' => 'background: #4f46e5; border: none; color: white; padding: 10px 20px; font-weight: bold; border-radius: 8px; cursor: pointer; box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);' ) ); ?>
                </div>
            </form>

            <div style="background: rgba(79, 70, 229, 0.05); border-radius: 12px; padding: 25px; margin-top: 30px; border: 1px solid rgba(79, 70, 229, 0.15);">
                <h3 style="color: #a5b4fc; margin-top: 0; font-size: 15px; font-weight: 700;">Local Page Generator</h3>
                <p style="color: #94a3b8; font-size: 13px; margin-bottom: 20px;">
                    Click below to dynamically generate standard B-LAN pages such as **B-LAN Profile Dashboard** and **B-LAN Community Directory**.
                </p>
                <form method="post" action="">
                    <?php wp_nonce_field( 'blan_recreate_nonce', 'blan_recreate_nonce' ); ?>
                    <input type="submit" name="blan_recreate_pages" class="button" value="Rapid Page Installation" style="background: transparent; border: 1px solid #4f46e5; color: #a5b4fc; padding: 8px 16px; font-weight: bold; border-radius: 8px; cursor: pointer;" />
                </form>
            </div>

            <div style="margin-top: 30px; border-top: 1px solid #1e293b; padding-top: 15px; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #475569;">
                <span>B-LAN Core Stack v3.0 // WP Module V.3</span>
                <span>Designed for 100% Offline Resilience</span>
            </div>
        </div>
    </div>
    <?php
}
`;

  const assetStyleCss = `/**
 * Stylesheet for B-LAN Plugin V.3
 */
.blan-widget-container {
    background: #0f172a;
    border: 1px solid #1e293b;
    border-radius: 20px;
    padding: 30px;
    color: #f1f5f9;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin: 20px 0;
}
.blan-card {
    background: #1e293b;
    border-radius: 16px;
    padding: 24px;
    border: 1px solid #334155;
    position: relative;
    overflow: hidden;
}
.blan-loading {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 40px 20px;
}
.blan-spinner {
    border: 3px solid rgba(99, 102, 241, 0.1);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border-left-color: #6366f1;
    animation: blan-spin 1s linear infinite;
    margin-bottom: 16px;
}
@keyframes blan-spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.blan-profile-header {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 24px;
    border-bottom: 1px solid #334155;
    padding-bottom: 20px;
}
.blan-avatar {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    border: 2px solid #6366f1;
    background: #0f172a;
}
.blan-name {
    font-size: 20px;
    font-weight: 800;
    margin: 0;
    color: #ffffff;
    text-transform: uppercase;
}
.blan-address {
    font-size: 13px;
    color: #94a3b8;
    margin: 4px 0 0;
}
.blan-stats-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.blan-stat-box {
    background: #0f172a;
    border-radius: 12px;
    padding: 16px;
    border: 1px solid #1e293b;
    text-align: center;
}
.blan-stat-label {
    font-size: 11px;
    color: #64748b;
    text-transform: uppercase;
    font-weight: 800;
    letter-spacing: 1px;
}
.blan-stat-value {
    font-size: 28px;
    font-weight: 900;
    margin-top: 6px;
}
.blan-stat-value.karma { color: #818cf8; }
.blan-stat-value.solar { color: #fbbf24; }
.blan-skills-section { margin-top: 20px; }
.blan-skills-title {
    font-size: 12px;
    color: #cbd5e1;
    text-transform: uppercase;
    font-weight: 800;
    letter-spacing: 1px;
    margin-bottom: 12px;
}
.blan-skills-list {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}
.blan-skill-tag {
    background: rgba(99, 102, 241, 0.1);
    color: #a5b4fc;
    border: 1px solid rgba(99, 102, 241, 0.2);
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
}
.blan-directory-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
}
.blan-member-card {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 16px;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: transform 0.2s, border-color 0.2s;
}
.blan-member-card:hover {
    transform: translateY(-2px);
    border-color: #6366f1;
}
.blan-member-info {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
}
.blan-member-avatar {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: #0f172a;
    border: 1.5px solid #6366f1;
}
.blan-member-name {
    font-size: 15px;
    font-weight: 700;
    color: white;
}
.blan-member-address {
    font-size: 11px;
    color: #64748b;
}
.blan-member-stats {
    display: flex;
    justify-content: space-between;
    background: #0f172a;
    border-radius: 10px;
    padding: 10px 14px;
    font-size: 11px;
    font-weight: bold;
}
`;

  const assetScriptJs = `/**
 * Frontend script for B-LAN Plugin V.3
 */
(function($) {
    'use strict';
    $(document).ready(function() {
        var nodeUrl = blanSettings.nodeUrl || 'http://localhost:3000';
        if ($('#blan-profile-root').length) {
            fetchProfileData(nodeUrl);
        }
        if ($('#blan-directory-root').length) {
            fetchDirectoryData(nodeUrl);
        }
    });

    function fetchProfileData(nodeUrl) {
        var root = $('#blan-profile-root');
        var cachedUser = null;
        try { cachedUser = JSON.parse(localStorage.getItem('current_auth_user')); } catch(e) {}
        var fallbackProfile = {
            name: "John Neighbor",
            address: "Sector B-4, Unit 12",
            karmaBalance: 520,
            solarWatts: 1450,
            skills: ["General Labor", "SDR Radio Setup", "Solar Maintenance"],
            avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=JohnNeighbor"
        };
        var user = cachedUser || fallbackProfile;
        setTimeout(function() {
            var html = '<div class="blan-card">' +
                '<div class="blan-profile-header">' +
                    '<img src="' + user.avatar + '" class="blan-avatar">' +
                    '<div>' +
                        '<h4 class="blan-name">' + user.name + '</h4>' +
                        '<p class="blan-address"><i class="fa-solid fa-location-dot"></i> ' + user.address + '</p>' +
                    '</div>' +
                '</div>' +
                '<div class="blan-stats-grid">' +
                    '<div class="blan-stat-box">' +
                        '<div class="blan-stat-label">Karma Trust Balance</div>' +
                        '<div class="blan-stat-value karma">' + user.karmaBalance + ' K</div>' +
                    '</div>' +
                    '<div class="blan-stat-box">' +
                        '<div class="blan-stat-label">Solar Watts Reserve</div>' +
                        '<div class="blan-stat-value solar">' + user.solarWatts.toLocaleString() + ' Wh</div>' +
                    '</div>' +
                '</div>' +
                '<div class="blan-skills-section">' +
                    '<div class="blan-skills-title">Active PIM Skills</div>' +
                    '<div class="blan-skills-list">' +
                        user.skills.map(function(s) { return '<span class="blan-skill-tag">' + s + '</span>'; }).join('') +
                    '</div>' +
                '</div>' +
            '</div>';
            root.html(html);
        }, 800);
    }

    function fetchDirectoryData(nodeUrl) {
        var root = $('#blan-directory-root');
        var fallbackMembers = [
            { name: "Alice Shard", address: "Sector A-1, Unit 09", karmaBalance: 1200, solarWatts: 4500 },
            { name: "Bob Node", address: "Sector B-2, Unit 04", karmaBalance: 320, solarWatts: 120 },
            { name: "Charlie Mesh", address: "Sector B-4, Unit 01", karmaBalance: 850, solarWatts: 2400 }
        ];
        var registry = [];
        try { registry = JSON.parse(localStorage.getItem('user_registry')) || []; } catch(e) {}
        var members = registry.length > 0 ? registry : fallbackMembers;
        setTimeout(function() {
            var html = '<div class="blan-directory-grid">';
            members.forEach(function(m) {
                var avatarUrl = m.avatar || "https://api.dicebear.com/7.x/bottts/svg?seed=" + m.name;
                html += '<div class="blan-member-card">' +
                    '<div class="blan-member-info">' +
                        '<img src="' + avatarUrl + '" class="blan-member-avatar">' +
                        '<div>' +
                            '<h5 class="blan-member-name">' + m.name + '</h5>' +
                            '<p class="blan-member-address">' + (m.address || "Sector B-4, Unit 12") + '</p>' +
                        '</div>' +
                    '</div>' +
                    '<div class="blan-member-stats">' +
                        '<span style="color: #a5b4fc;"><i class="fa-solid fa-coins"></i> ' + (m.karmaBalance || 500) + ' K</span>' +
                        '<span style="color: #fbbf24;"><i class="fa-solid fa-bolt"></i> ' + (m.solarWatts || 1000).toLocaleString() + ' Wh</span>' +
                    '</div>' +
                '</div>';
            });
            html += '</div>';
            root.html(html);
        }, 1000);
    }
})(jQuery);
`;

  const handleDownloadPlugin = async () => {
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      const zip = new JSZip();

      // Set up directory structure
      const folder = zip.folder("b-lan-plugin");
      if (folder) {
        folder.file("b-lan-plugin.php", bLanPluginPhp);
        
        const includes = folder.folder("includes");
        if (includes) {
          includes.file("admin-settings.php", adminSettingsPhp);
        }

        const assets = folder.folder("assets");
        if (assets) {
          const css = assets.folder("css");
          if (css) css.file("style.css", assetStyleCss);

          const js = assets.folder("js");
          if (js) js.file("script.js", assetScriptJs);
        }
      }

      // Generate the ZIP file asynchronously
      const content = await zip.generateAsync({ type: "blob" });

      // Create download trigger element
      const element = document.createElement("a");
      element.href = URL.createObjectURL(content);
      element.download = "b-lan-plugin-v3.zip";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      setDownloadSuccess(true);
    } catch (error) {
      console.error("Error creating ZIP:", error);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadDirectZip = async (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setIsDownloading(true);
    try {
      const response = await fetch('/b-lan-plugin-v3.zip');
      if (!response.ok) throw new Error('ZIP file not found on server');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'b-lan-plugin-v3.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setDownloadSuccess(true);
    } catch (err) {
      console.error('Error downloading WordPress plugin:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-8 md:space-y-12 animate-fadeIn max-w-5xl mx-auto pb-16">
      
      {/* Title Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-6">
        <div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight">WordPress Mesh Integration</h1>
          <p className="text-slate-400 text-sm mt-1">Deploy secure, local-first member profiles and community directories on WordPress websites.</p>
        </div>
        <div className="flex items-center gap-3 bg-indigo-500/10 px-4 py-2 rounded-full border border-indigo-500/20 text-indigo-400 text-xs font-black uppercase tracking-widest">
          <i className="fa-brands fa-wordpress text-base"></i>
          <span>B-LAN Plugin V.3</span>
        </div>
      </div>

      {/* Main Download & Integration Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-10">
        
        {/* Left column: Action / Download Box */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-gradient-to-b from-slate-900 to-indigo-950/20 border-2 border-indigo-500/30 rounded-[2.5rem] p-8 md:p-10 shadow-2xl relative overflow-hidden flex flex-col justify-between h-full min-h-[400px]">
            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
              <i className="fa-brands fa-wordpress text-[12rem] text-indigo-500"></i>
            </div>
            
            <div className="space-y-6">
              <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border-2 border-indigo-500/20 flex items-center justify-center text-indigo-400 text-2xl">
                <i className="fa-solid fa-box-archive"></i>
              </div>
              <h2 className="text-2xl font-black text-white uppercase tracking-tight">Generate Local Shard Plugin</h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                Bundles the main integration wrapper, rapid-installation wizard, template scripts, and custom stylesheet into a downloadable ready-to-upload ZIP package.
              </p>
            </div>

            <div className="space-y-4 pt-10">
              <button
                onClick={handleDownloadPlugin}
                disabled={isDownloading}
                className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-3 ${
                  isDownloading 
                    ? 'bg-slate-800 text-slate-500 cursor-wait' 
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 active:scale-95'
                }`}
              >
                {isDownloading ? (
                  <div className="w-5 h-5 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <Download className="w-5 h-5" />
                )}
                <span>{isDownloading ? 'Packaging Shard...' : 'Download Plugin ZIP'}</span>
              </button>

              <div className="text-center pt-2">
                <a 
                  href="/b-lan-plugin-v3.zip" 
                  onClick={handleDownloadDirectZip}
                  className="text-indigo-400 hover:text-indigo-300 text-xs font-black uppercase tracking-wider hover:underline inline-flex items-center gap-2"
                >
                  <i className="fa-solid fa-cloud-arrow-down"></i>
                  Download Pre-packaged v3 ZIP Directly (Static Mirror)
                </a>
              </div>

              {downloadSuccess && (
                <div className="flex items-center gap-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-5 py-4 rounded-xl text-xs font-black uppercase tracking-wider animate-fadeIn">
                  <CheckCircle className="w-5 h-5 shrink-0" />
                  <span>Download Complete! File saved as b-lan-plugin-v3.zip</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right column: Specs, Shortcodes & Setup Instructions */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Rapid Installation */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-xl">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Settings className="w-4 h-4 text-indigo-500" />
              Rapid Installation Wizard
            </h3>
            <div className="space-y-6">
              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold shrink-0 text-sm">1</div>
                <div>
                  <h4 className="text-white font-bold text-sm uppercase tracking-tight">Upload & Activate</h4>
                  <p className="text-slate-400 text-xs mt-1 leading-relaxed">
                    Navigate to **Plugins &gt; Add New &gt; Upload Plugin** in your WordPress Dashboard. Select the downloaded `b-lan-plugin-v3.zip` file, upload, and activate it.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold shrink-0 text-sm">2</div>
                <div>
                  <h4 className="text-white font-bold text-sm uppercase tracking-tight">Automated Member Page Creation</h4>
                  <p className="text-slate-400 text-xs mt-1 leading-relaxed">
                    Upon activation, the plugin automatically creates two essential mesh pages: **B-LAN Profile Dashboard** (`/blan-profile`) and **B-LAN Community Directory** (`/blan-directory`).
                  </p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold shrink-0 text-sm">3</div>
                <div>
                  <h4 className="text-white font-bold text-sm uppercase tracking-tight">Configure local node url</h4>
                  <p className="text-slate-400 text-xs mt-1 leading-relaxed">
                    Go to the new **B-LAN Mesh** side menu inside WordPress. Type your physical B-LAN Node URL (e.g. `http://localhost:3000` or local mesh IP) and save settings.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Shortcode Reference */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-xl">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Code className="w-4 h-4 text-indigo-500" />
              Member Page Creation Shortcodes
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-950 p-5 rounded-2xl border border-white/5 space-y-3">
                <div className="font-mono text-indigo-400 text-xs font-black">[blan_member_profile]</div>
                <h4 className="text-slate-200 font-bold text-xs uppercase tracking-tight">Member Profile Widget</h4>
                <p className="text-slate-500 text-[11px] leading-relaxed">
                  Renders the B-LAN identity card displaying Unit Address, active PIM skills, and current synced Karma Ledger balances.
                </p>
              </div>

              <div className="bg-slate-950 p-5 rounded-2xl border border-white/5 space-y-3">
                <div className="font-mono text-indigo-400 text-xs font-black">[blan_community_directory]</div>
                <h4 className="text-slate-200 font-bold text-xs uppercase tracking-tight">Community Directory</h4>
                <p className="text-slate-500 text-[11px] leading-relaxed">
                  Displays a beautiful catalog of neighboring peers active in the configured Community Information Module (CIM) mesh.
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};

export default WordPressPlugin;
